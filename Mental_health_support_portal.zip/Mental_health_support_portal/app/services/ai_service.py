"""
AI Service Layer.
Currently uses mock responses.
Can be replaced with OpenAI API easily.
"""

import random


def generate_ai_response(user_message: str) -> str:
    """
    Generates a mock therapeutic response.
    Replace this function later with real OpenAI call.
    """

    supportive_responses = [
        "I'm really glad you shared that. How long have you been feeling this way?",
        "That sounds difficult. What do you think is contributing to these feelings?",
        "It’s okay to feel overwhelmed sometimes. Would you like to talk more about it?",
        "You're not alone in this. I'm here to listen.",
        "What usually helps you cope during moments like this?",
        "That sounds important. Can you tell me more about what happened?"
    ]

    # Simple emotional keyword detection
    if "sad" in user_message.lower():
        return "I'm sorry you're feeling sad. Would you like to share what's been weighing on you?"

    if "anxious" in user_message.lower():
        return "Anxiety can be really overwhelming. What seems to trigger it for you?"

    if "stress" in user_message.lower():
        return "Stress can build up quietly. What's been causing stress recently?"

    return random.choice(supportive_responses)
