"""
Handles encryption and decryption of journal entries.
"""

from cryptography.fernet import Fernet
import os
from dotenv import load_dotenv

load_dotenv()

# Generate this once and store in .env in real production
SECRET_ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY")

# If not set, generate a temporary one
if not SECRET_ENCRYPTION_KEY:
    SECRET_ENCRYPTION_KEY = Fernet.generate_key()

cipher = Fernet(SECRET_ENCRYPTION_KEY)


def encrypt_text(text: str) -> bytes:
    return cipher.encrypt(text.encode())


def decrypt_text(token: bytes) -> str:
    return cipher.decrypt(token).decode()
