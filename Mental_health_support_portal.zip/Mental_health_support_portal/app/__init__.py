from flask import Flask
from .config import Config
from .extensions import db, login_manager, jwt, migrate


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)
    jwt.init_app(app)
    migrate.init_app(app, db)

    # Import models so migrations detect them
    with app.app_context():
        from . import models

    # Register blueprints
    from app.routes.auth import auth_bp
    app.register_blueprint(auth_bp)

    from app.routes.dashboard import dashboard_bp
    app.register_blueprint(dashboard_bp)

    from app.routes.ai_chat import chat_bp
    app.register_blueprint(chat_bp)

    from app.routes.mood_tracker import mood_bp
    app.register_blueprint(mood_bp)

    from app.routes.journal import journal_bp
    app.register_blueprint(journal_bp)

    # TEMPORARY DASHBOARD ROUTE (ADD HERE)
    # @app.route("/dashboard")
    # def dashboard():
    #     return "Welcome to Dashboard 🎉"

    return app
