from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required

from app.services.ai_service import generate_ai_response

chat_bp = Blueprint("chat", __name__, url_prefix="/chat")


@chat_bp.route("/")
@login_required
def chat_page():
    return render_template("chat.html")


@chat_bp.route("/message", methods=["POST"])
@login_required
def chat_message():
    user_message = request.json.get("message")

    ai_reply = generate_ai_response(user_message)

    return jsonify({"reply": ai_reply})
