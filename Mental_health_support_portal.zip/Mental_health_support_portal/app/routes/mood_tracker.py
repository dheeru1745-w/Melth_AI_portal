from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import date

from app.extensions import db
from app.models.mood import Mood

mood_bp = Blueprint("mood", __name__, url_prefix="/mood")


@mood_bp.route("/", methods=["GET", "POST"])
@login_required
def mood_home():
    if request.method == "POST":
        mood_level = int(request.form["mood_level"])
        note = request.form.get("note")

        new_mood = Mood(
            mood_level=mood_level,
            note=note,
            mood_date=date.today(),
            user_id=current_user.id
        )

        db.session.add(new_mood)
        db.session.commit()

        flash("Mood recorded successfully!", "success")
        return redirect(url_for("mood.mood_home"))

    moods = Mood.query.filter_by(user_id=current_user.id).order_by(Mood.mood_date.desc()).all()

    return render_template("mood.html", moods=moods)
