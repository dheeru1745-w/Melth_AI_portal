from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user

from app.extensions import db
from app.models.journal import Journal
from app.services.encryption import encrypt_text, decrypt_text

journal_bp = Blueprint("journal", __name__, url_prefix="/journal")


@journal_bp.route("/", methods=["GET", "POST"])
@login_required
def journal_home():
    if request.method == "POST":
        content = request.form["content"]

        encrypted = encrypt_text(content)

        entry = Journal(
            encrypted_content=encrypted,
            user_id=current_user.id
        )

        db.session.add(entry)
        db.session.commit()

        flash("Journal entry saved securely!", "success")
        return redirect(url_for("journal.journal_home"))

    entries = Journal.query.filter_by(user_id=current_user.id).order_by(Journal.created_at.desc()).all()

    decrypted_entries = []
    for entry in entries:
        decrypted_entries.append({
            "content": decrypt_text(entry.encrypted_content),
            "created_at": entry.created_at
        })

    return render_template("journal.html", entries=decrypted_entries)
