# Central configuration file.
# All environment variables are loaded here.


import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()


class Config:
    # Core Flask config
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")

    # Database
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL", "sqlite:///mental_health.db"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # JWT configuration
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "jwt-dev-secret")

    # AI API (OpenAI or local LLM)
    AI_API_KEY = os.getenv("AI_API_KEY")

    # Security
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SECURE = False  # True in production
