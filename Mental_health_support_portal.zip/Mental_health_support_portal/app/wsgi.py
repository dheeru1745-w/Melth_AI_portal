"""
WSGI entry point for Flask CLI and production servers.
This file makes Flask-Migrate work reliably.
"""

from app import create_app

app = create_app()
