"""
Model package initializer.
Imports all models so SQLAlchemy can detect them.
"""

from .user import User
from .mood import Mood
from .journal import Journal
from .appointment import Appointment
