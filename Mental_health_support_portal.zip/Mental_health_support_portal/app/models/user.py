"""
User model.
Handles authentication and user identity.
"""

from datetime import datetime
from flask_login import UserMixin
from app.extensions import db
from app.extensions import login_manager


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)

    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    role = db.Column(db.String(20), default="user")  # user / admin / counselor

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    moods = db.relationship("Mood", backref="user", lazy=True)
    journals = db.relationship("Journal", backref="user", lazy=True)
    appointments = db.relationship("Appointment", backref="user", lazy=True)

    def __repr__(self):
        return f"<User {self.username}>"

    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))