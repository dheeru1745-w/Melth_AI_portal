"""
Appointment model.
Handles counselor booking.
"""

from datetime import datetime
from app.extensions import db


class Appointment(db.Model):
    __tablename__ = "appointments"

    id = db.Column(db.Integer, primary_key=True)

    counselor_name = db.Column(db.String(100), nullable=False)
    appointment_time = db.Column(db.DateTime, nullable=False)

    status = db.Column(
        db.String(20), default="scheduled"
    )  # scheduled / completed / cancelled

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Appointment {self.counselor_name} at {self.appointment_time}>"
