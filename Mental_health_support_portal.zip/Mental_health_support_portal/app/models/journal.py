"""
Journal model.
Stores encrypted private journal entries.
"""

from datetime import datetime
from app.extensions import db


class Journal(db.Model):
    __tablename__ = "journals"

    id = db.Column(db.Integer, primary_key=True)

    encrypted_content = db.Column(db.LargeBinary, nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    def __repr__(self):
        return f"<Journal Entry {self.id}>"
