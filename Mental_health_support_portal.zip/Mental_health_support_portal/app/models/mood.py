"""
Mood tracking model.
Stores user's emotional state per day.
"""

from datetime import date
from app.extensions import db


class Mood(db.Model):
    __tablename__ = "moods"

    id = db.Column(db.Integer, primary_key=True)

    mood_level = db.Column(db.Integer, nullable=False)  # 1–10 scale
    note = db.Column(db.String(255))

    mood_date = db.Column(db.Date, default=date.today)

    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    def __repr__(self):
        return f"<Mood {self.mood_level} on {self.mood_date}>"
