from app import create_app

app = create_app()

if __name__ == "__main__":
    app.run(debug=True)


# Application entry point.
# Used for local development.